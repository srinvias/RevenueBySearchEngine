# -*- coding: utf-8 -*-

neutral = [
    'Se abre el ascensor y hay un programador dentro, le preguntan: - Sube o baja? A lo que el programador responde: - Si.',
    'Que le dice un bit al otro? Nos vemos en el bus.',
    'Atracador: El dinero o la vida! Programador: Lo siento, soy programador. Atracador: Y? Programador: No tengo dinero ni vida.',
    'Que es un terapeuta? - 1024 Gigapeutas',
    'Cuantos programadores hacen falta para cambiar una bombilla? - Ninguno, porque es un problema de hardware.',
    'Se abre el telon, aparece un informatico y dice: que habeis tocado que no se cierra el telon!',
    '- ...fallece una persona mientras estudiaba en la biblioteca - Que estaba estudiando? - La API de Windows.',
    'Que le dice un GIF a un JPG? -Animate hombre...',
    'Que dice un informatico que se esta ahogando en la playa?: F1, F1!',
    'Solo hay 10 tipos de personas en el mundo, las que entienden binario y las que no.',
    'Solo hay 10 tipos de personas en el mundo: las que entienden trinario, las que no, y las que lo confunden con binario.',
    'Una mujer dice a su marido informatico: - Ve al supermercado y trae una barra de pan, y si hay huevos, doce. Trajo doce barras de pan.',
    'Quien demonios es el general Failure, y que hace intentando leer de mi disco duro?',
    'En que se diferencian Windows y un virus? En que el virus funciona, y es gratis.'
]

jokes_es = {
    'neutral': neutral,
    'all': neutral,
}
